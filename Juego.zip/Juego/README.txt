Integrantes del equipo:

Maciel L�pez Nydia Beatriz
Reyes Hern�ndez Nabi
V�squez Cruz Yanet de los �ngeles

Despu�s de terminar los niveles por primera vez, hay que dar un click, puesto que el audio no reproduce por si solo.