
INTEGRANTES DEL EQUIPO:

	Maciel López Nydia Beatriz
	Reyes Hernández Nabi
	Torres Bautista Jazmin
	Vásquez Cruz Yanet de los Ángeles



Acerca del juego:

Hay que tener cuidado de equivocarse al seleccionar la ficha y a donce se va a mover. En caso de equivocarse dar doble click sobre la ficha a mover y despues se puede continuar dando un click sencillo.